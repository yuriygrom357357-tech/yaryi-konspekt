﻿$ErrorActionPreference = 'Stop'
$data  = Split-Path -Parent $PSScriptRoot
$index = Join-Path $data 'index.html'
$url   = 'file:///' + ($index -replace '\\','/')
$ico   = Join-Path $data 'icons\yaryi.ico'
$prof  = Join-Path $env:LOCALAPPDATA 'YaryiApp'
$cands = @(
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe")
$br = $cands | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
$ws = New-Object -ComObject WScript.Shell
function Make($dir) {
  $l = $ws.CreateShortcut((Join-Path $dir 'ЯРИЙ.lnk'))
  if ($br) { $l.TargetPath = $br; $l.Arguments = "--user-data-dir=`"$prof`" --allow-file-access-from-files --app=`"$url`" --window-size=1280,900" }
  else { $l.TargetPath = $index }
  $l.WorkingDirectory = $data
  $l.IconLocation = "$ico,0"
  $l.Description = 'ЯРИЙ — помічник конспектів'
  $l.Save()
}
Make ([Environment]::GetFolderPath('Desktop'))
try { Make ([Environment]::GetFolderPath('Programs')) } catch {}
Write-Host ''
Write-Host '  ✓ Готово! Значок «ЯРИЙ» (мушка) з’явився на робочому столі та в меню «Пуск».' -ForegroundColor Green
if (-not $br) { Write-Host '  Chrome / Edge не знайдено — додаток відкриватиметься у браузері за замовчуванням.' -ForegroundColor Yellow }
Write-Host '  Не переміщуйте папку «ЯРИЙ» після створення ярлика (або створіть ярлик заново).'
