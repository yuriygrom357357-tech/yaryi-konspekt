@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0yaryi-data\setup\shortcut.ps1"
echo.
pause
