#!/bin/bash
# Додає значок «ЯРИЙ» на робочий стіл Mac
DIR="$(cd "$(dirname "$0")" && pwd)"
xattr -dr com.apple.quarantine "$DIR/ЯРИЙ.app" 2>/dev/null
osascript -e "tell application \"Finder\" to make alias file to POSIX file \"$DIR/ЯРИЙ.app\" at desktop" >/dev/null && echo "✓ Значок «ЯРИЙ» додано на робочий стіл." || echo "Перетягніть «ЯРИЙ» на робочий стіл або в Dock вручну."
