@echo off
chcp 65001 >nul
set "F=%~dp0yaryi-data\index.html"
set "U=file:///%F:\=/%"
set "P=%LocalAppData%\YaryiApp"
for %%B in ("%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%LocalAppData%\Google\Chrome\Application\chrome.exe" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe") do (
  if exist %%B (
    start "" %%B --user-data-dir="%P%" --allow-file-access-from-files --app="%U%" --window-size=1280,900
    exit /b
  )
)
start "" "%F%"
